<?php
Advanced_Ads_Pro_Placement_Tests::get_instance();