<label>
    <input style="width:4em;" type="number" name="advads-groups[<?php echo $group->id; ?>][options][grid][inner_margin]" value="<?php echo $inner_margin; ?>" min="0" max="50"/> %
</label>