<?php
new Advanced_Ads_Pro_Weekdays;