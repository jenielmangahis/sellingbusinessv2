<input name="<?php echo Advanced_Ads_Selling_Plugin::OPTION_KEY; ?>[wc-fixes]" type="checkbox" value="1" <?php checked( 1, $wc_fixes ); ?>/>
<p class="description"><?php _e( 'Apply general WooCommerce fixes. Especially useful, when you don’t use WooCommerce for anything else than ads. See the list of changes below.', 'advanced-ads-selling' ); ?></p>
<ul>
    <li><?php _e( 'Remove product images', 'advanced-ads-selling' ); ?></li>
</ul>