<?php
/**
 * Moove_Importer_Shortcodes File Doc Comment
 *
 * @category  Moove_Importer_Shortcodes
 * @package   moove-feed-importer
 * @author    Gaspar Nemes
 */

/**
 * Moove_Importer_Shortcodes Class Doc Comment
 *
 * @category Class
 * @package  Moove_Importer_Shortcodes
 * @author   Gaspar Nemes
 */
class Moove_Importer_Shortcodes {
	/**
	 * Construct function
	 */
	function __construct() {

	}
}
$moove_importer_shortcodes_provider = new Moove_Importer_Shortcodes();
