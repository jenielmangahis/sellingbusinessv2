<div class="moove-importer-plugin-documentation">
    <br>
    <h1><?php _e( 'Moove Feed Importer Plugin Addons' , 'import-xml-feed' ); ?></h1>
</div>
<!-- moove-activity-plugin-documentation -->