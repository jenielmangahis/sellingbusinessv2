<?php
	/**
	 * Registering CONTROLLERS
	 */
	include_once( dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'controllers' . DIRECTORY_SEPARATOR . 'moove-controller.php' );
    include_once( dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'controllers' . DIRECTORY_SEPARATOR . 'moove-functions.php' );
?>
